Andes Shaders v1.0.2
=================================

Shaders para Minecraft Java 1.21.11 con Iris 1.10 o superior
(Fabric, NeoForge o Quilt, junto a Sodium).

Instalacion
-----------
1. Copia este archivo .zip en la carpeta "shaderpacks" de tu instalacion
   de Minecraft (Options > Video Settings > Shader Packs > "Open Shader
   Pack Folder").
2. Dentro del juego: Options > Video Settings > Shader Packs y elige
   "Andes Shaders".
3. Ajusta el pack en "Shader Pack Settings": hay perfiles (Patata, Rapido,
   Equilibrado, Alto, Ultra) y opciones de sombras, agua, viento y color.

Si el pack no aparece en la lista, comprueba que el .zip no tenga una
carpeta de mas: dentro del zip la carpeta debe llamarse "shaders".

Licencia MIT. No incluye texturas: usa las de Minecraft.
